import React from 'react';
import { Link, useLocation } from 'react-router-dom';
import { FaLeaf, FaSignOutAlt, FaThermometerHalf, FaInfoCircle, FaBook } from 'react-icons/fa';
import './Navbar.css';

const Navbar = ({ logout }) => {
  const location = useLocation();
  
  return (
    <nav className="navbar">
      <div className="navbar-container">
        <Link to="/" className="navbar-logo">
          <FaLeaf className="navbar-icon" />
          <span>Smart Agriculture</span>
        </Link>
        
        <ul className="navbar-menu">
          <li className="navbar-item">
            <Link 
              to="/" 
              className={location.pathname === '/' ? 'navbar-link active' : 'navbar-link'}
            >
              <FaThermometerHalf className="navbar-link-icon" />
              <span>Dashboard</span>
            </Link>
          </li>
          <li className="navbar-item">
            <Link 
              to="/pesticides" 
              className={location.pathname === '/pesticides' ? 'navbar-link active' : 'navbar-link'}
            >
              <FaBook className="navbar-link-icon" />
              <span>Pesticides</span>
            </Link>
          </li>
          <li className="navbar-item">
            <Link 
              to="/more-info" 
              className={location.pathname === '/more-info' ? 'navbar-link active' : 'navbar-link'}
            >
              <FaInfoCircle className="navbar-link-icon" />
              <span>More Info</span>
            </Link>
          </li>
          <li className="navbar-item">
            <Link 
              to="/about" 
              className={location.pathname === '/about' ? 'navbar-link active' : 'navbar-link'}
            >
              <FaInfoCircle className="navbar-link-icon" />
              <span>About</span>
            </Link>
          </li>
          <li className="navbar-item">
            <button onClick={logout} className="navbar-link logout-btn">
              <FaSignOutAlt className="navbar-link-icon" />
              <span>Logout</span>
            </button>
          </li>
        </ul>
      </div>
    </nav>
  );
};

export default Navbar;